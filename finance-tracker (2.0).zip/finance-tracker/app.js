const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

// Middleware setup
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({ secret: 'your-secret-key', resave: false, saveUninitialized: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Connect to SQLite DB
const db = new sqlite3.Database('database.db');
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    isAdmin INTEGER DEFAULT 0
  )`);
  
  db.run(`CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    userId INTEGER,
    type TEXT,
    amount REAL,
    description TEXT,
    date TEXT,
    FOREIGN KEY(userId) REFERENCES users(id)
  )`);
  
  // Seed admin user
  db.get("SELECT * FROM users WHERE username = 'admin'", (err, row) => {
    if (!row) {
      const hashedPw = bcrypt.hashSync('admin123', 10);
      db.run("INSERT INTO users (username, password, isAdmin) VALUES (?, ?, 1)", ['admin', hashedPw]);
    }
  });
});

// Authentication middleware
function isAuthenticated(req, res, next) {
  if (req.session.userId) {
    return next();
  }
  res.redirect('/');
}

// Admin middleware
function isAdmin(req, res, next) {
  if (req.session.isAdmin) {
    return next();
  }
  res.redirect('/dashboard');
}

// Routes
app.get('/', (req, res) => {
  res.render('login', { error: null });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  db.get("SELECT * FROM users WHERE username = ?", [username], (err, user) => {
    if (user && bcrypt.compareSync(password, user.password)) {
      req.session.userId = user.id;
      req.session.isAdmin = user.isAdmin;
      res.redirect('/dashboard');
    } else {
      res.render('login', { error: 'Invalid username or password' });
    }
  });
});

app.get('/register', (req, res) => {
  res.render('register', { error: null });
});

app.post('/register', (req, res) => {
  const { username, password } = req.body;
  const hashedPw = bcrypt.hashSync(password, 10);
  db.run("INSERT INTO users (username, password) VALUES (?, ?)", [username, hashedPw], (err) => {
    if (err) {
      res.render('register', { error: 'Username already exists' });
    } else {
      res.redirect('/');
    }
  });
});

app.get('/dashboard', isAuthenticated, (req, res) => {
  db.get("SELECT id, username FROM users WHERE id = ?", [req.session.userId], (err, user) => {
    db.all("SELECT * FROM transactions WHERE userId = ? ORDER BY date DESC", [req.session.userId], (err, transactions) => {
      let income = 0, expense = 0;
      transactions.forEach(t => {
        if (t.type === 'income') income += t.amount;
        else expense += t.amount;
      });
      res.render('dashboard', { transactions, balance: income - expense, income, expense, isAdmin: req.session.isAdmin, user });
    });
  });
});

app.get('/add', isAuthenticated, (req, res) => {
  res.render('add', { isAdmin: req.session.isAdmin });
});

app.post('/add', isAuthenticated, (req, res) => {
  const { type, amount, description, date } = req.body;
  db.run("INSERT INTO transactions (userId, type, amount, description, date) VALUES (?, ?, ?, ?, ?)",
    [req.session.userId, type, parseFloat(amount), description, date],
    () => res.redirect('/dashboard')
  );
});

app.get('/edit/:id', isAuthenticated, (req, res) => {
  db.get("SELECT * FROM transactions WHERE id = ? AND userId = ?", [req.params.id, req.session.userId], (err, transaction) => {
    if (transaction) {
      res.render('edit', { transaction, isAdmin: req.session.isAdmin });
    } else {
      res.redirect('/dashboard');
    }
  });
});

app.post('/edit/:id', isAuthenticated, (req, res) => {
  const { type, amount, description, date } = req.body;
  db.run("UPDATE transactions SET type = ?, amount = ?, description = ?, date = ? WHERE id = ? AND userId = ?",
    [type, parseFloat(amount), description, date, req.params.id, req.session.userId],
    () => res.redirect('/dashboard')
  );
});

app.post('/delete/:id', isAuthenticated, (req, res) => {
  db.run("DELETE FROM transactions WHERE id = ? AND userId = ?", [req.params.id, req.session.userId], () => {
    res.redirect('/dashboard');
  });
});

app.get('/admin', isAdmin, (req, res) => {
  db.all("SELECT id, username, isAdmin FROM users", (err, users) => {
    res.render('admin', { users, isAdmin: req.session.isAdmin });
  });
});

app.post('/delete-user/:id', isAdmin, (req, res) => {
  db.run("DELETE FROM users WHERE id = ?", [req.params.id], () => {
    db.run("DELETE FROM transactions WHERE userId = ?", [req.params.id]);
    res.redirect('/admin');
  });
});

app.get('/edit-user/:id', isAdmin, (req, res) => {
  db.get("SELECT id, username FROM users WHERE id = ?", [req.params.id], (err, user) => {
    if (user) {
      res.render('edit-user', { user, isAdmin: req.session.isAdmin, error: null });
    } else {
      res.redirect('/admin');
    }
  });
});

app.post('/edit-user/:id', isAdmin, (req, res) => {
  const { username, password } = req.body;
  const updates = [];
  const params = [];
  
  if (username) {
    updates.push("username = ?");
    params.push(username);
  }
  if (password) {
    const hashedPw = bcrypt.hashSync(password, 10);
    updates.push("password = ?");
    params.push(hashedPw);
  }
  
  if (updates.length === 0) {
    db.get("SELECT id, username FROM users WHERE id = ?", [req.params.id], (err, user) => {
      res.render('edit-user', { user, isAdmin: req.session.isAdmin, error: 'No changes provided' });
    });
    return;
  }
  
  params.push(req.params.id);
  const query = `UPDATE users SET ${updates.join(', ')} WHERE id = ?`;
  
  db.run(query, params, function(err) {
    if (err) {
      db.get("SELECT id, username FROM users WHERE id = ?", [req.params.id], (err, user) => {
        res.render('edit-user', { user, isAdmin: req.session.isAdmin, error: 'Username already exists' });
      });
    } else {
      res.redirect('/admin');
    }
  });
});

app.get('/edit-profile', isAuthenticated, (req, res) => {
  db.get("SELECT id, username FROM users WHERE id = ?", [req.session.userId], (err, user) => {
    if (user) {
      res.render('edit-profile', { user, isAdmin: req.session.isAdmin, error: null });
    } else {
      res.redirect('/dashboard');
    }
  });
});

app.post('/edit-profile', isAuthenticated, (req, res) => {
  const { username, password } = req.body;
  const updates = [];
  const params = [];
  
  if (username) {
    updates.push("username = ?");
    params.push(username);
  }
  if (password) {
    const hashedPw = bcrypt.hashSync(password, 10);
    updates.push("password = ?");
    params.push(hashedPw);
  }
  
  if (updates.length === 0) {
    db.get("SELECT id, username FROM users WHERE id = ?", [req.session.userId], (err, user) => {
      res.render('edit-profile', { user, isAdmin: req.session.isAdmin, error: 'No changes provided' });
    });
    return;
  }
  
  params.push(req.session.userId);
  const query = `UPDATE users SET ${updates.join(', ')} WHERE id = ?`;
  
  db.run(query, params, function(err) {
    if (err) {
      db.get("SELECT id, username FROM users WHERE id = ?", [req.session.userId], (err, user) => {
        res.render('edit-profile', { user, isAdmin: req.session.isAdmin, error: 'Username already exists' });
      });
    } else {
      // Update session username if changed
      if (username) {
        db.get("SELECT username FROM users WHERE id = ?", [req.session.userId], (err, user) => {
          req.session.username = user.username;
          res.redirect('/dashboard');
        });
      } else {
        res.redirect('/dashboard');
      }
    }
  });
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});